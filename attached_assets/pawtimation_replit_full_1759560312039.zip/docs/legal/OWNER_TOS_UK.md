Owner Terms (UK) — see chat version.
