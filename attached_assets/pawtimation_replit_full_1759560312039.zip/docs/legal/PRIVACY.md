Privacy draft — see chat version.
