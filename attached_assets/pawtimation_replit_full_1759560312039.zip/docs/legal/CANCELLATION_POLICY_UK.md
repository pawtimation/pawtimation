Cancellation Policy (UK) — see chat version.
