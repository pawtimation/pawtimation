import React from 'react'
export const Star=(p)=>(<svg width='16' height='16' viewBox='0 0 24 24' {...p}><path d='m12 17.27 6.18 3.73-1.64-7.03L21 9.24l-7.19-.61L12 2 10.19 8.63 3 9.24l4.46 4.73L5.82 21z'/></svg>)
