import React from 'react'
export function Badge({children,className=''}){return <span className={`badge ${className}`}>{children}</span>}
