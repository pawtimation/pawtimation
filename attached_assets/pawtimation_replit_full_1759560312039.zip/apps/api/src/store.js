export const db = { users:{}, pets:{}, sitters:{}, invites:{}, bookings:{}, updates:{}, agreements:{}, cancellations:{} };
